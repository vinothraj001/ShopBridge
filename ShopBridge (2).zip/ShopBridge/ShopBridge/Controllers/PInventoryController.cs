﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ShopBridge.Models;

namespace ShopBridge.Controllers
{
    public class PInventoryController : ApiController
    {
        private DBModel db = new DBModel();

        // GET: api/PInventory
        public IQueryable<ProductInventory> GetProductInventories()
        {
            return db.ProductInventories;
        }

        // GET: api/PInventory/5
        [ResponseType(typeof(ProductInventory))]
        public IHttpActionResult GetProductInventory(int id)
        {
            ProductInventory productInventory = db.ProductInventories.Find(id);
            if (productInventory == null)
            {
                return NotFound();
            }

            return Ok(productInventory);
        }

        // PUT: api/PInventory/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProductInventory(int id, ProductInventory productInventory)
        {
            

            if (id != productInventory.ID)
            {
                return BadRequest();
            }

            db.Entry(productInventory).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductInventoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/PInventory
        [ResponseType(typeof(ProductInventory))]
        public IHttpActionResult PostProductInventory(ProductInventory productInventory)
        { 

            db.ProductInventories.Add(productInventory);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = productInventory.ID }, productInventory);
        }

        // DELETE: api/PInventory/5
        [ResponseType(typeof(ProductInventory))]
        public IHttpActionResult DeleteProductInventory(int id)
        {
            ProductInventory productInventory = db.ProductInventories.Find(id);
            if (productInventory == null)
            {
                return NotFound();
            }

            db.ProductInventories.Remove(productInventory);
            db.SaveChanges();

            return Ok(productInventory);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ProductInventoryExists(int id)
        {
            return db.ProductInventories.Count(e => e.ID == id) > 0;
        }
    }
}