﻿using System;
using System.ComponentModel.DataAnnotations;


namespace ShopBrigdeUI.Models
{
    public class MVCproduct
    {
        public int ID { get; set; }
        //Name is mandatory
        [Required(ErrorMessage ="This feild is required")]
        public string Name { get; set; }
        public string Description { get; set; }
        public Nullable<double> Price { get; set; }

    }
}