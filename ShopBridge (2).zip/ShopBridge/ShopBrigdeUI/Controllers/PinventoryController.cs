﻿using ShopBrigdeUI.Models;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Mvc;

namespace ShopBrigdeUI.Controllers
{
    public class PinventoryController : Controller
    {
        // GET: inventory
        public ActionResult Index()
        {
            IEnumerable<MVCproduct> productList;
            HttpResponseMessage response = Globalvariable.WebApiClient.GetAsync("Pinventory").Result;
            productList = response.Content.ReadAsAsync<IEnumerable<MVCproduct>>().Result;
            return View(productList);
        }
        //Get inventory using ID
        public ActionResult AddOrEdit(int id = 0)
        {
            if (id == 0)
                return View(new MVCproduct());
            else
            {
                HttpResponseMessage response = Globalvariable.WebApiClient.GetAsync("Pinventory/" + id.ToString()).Result;
                return View(response.Content.ReadAsAsync<MVCproduct>().Result);
            } 
        }
        //Using http put and post to update and add the inventory records
        [HttpPost]
        public ActionResult AddOrEdit(MVCproduct pro)
        {

            if (pro.ID == 0)
            {
                HttpResponseMessage response = Globalvariable.WebApiClient.PostAsJsonAsync("Pinventory", pro).Result;
                TempData["SuccessMessage"] = "Saved Successfully";
            }
            else
            {
                HttpResponseMessage response = Globalvariable.WebApiClient.PutAsJsonAsync("Pinventory/" + pro.ID, pro).Result;
                TempData["SuccessMessage"] = "Updated Successfully";
            }
            
            return RedirectToAction("Index");
        }

        //Delete inventory records
        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = Globalvariable.WebApiClient.DeleteAsync("Pinventory/" + id.ToString()).Result;
            TempData["SuccessMessage"] = "Deleted Successfully";
            return RedirectToAction("Index");
        }
    }
}