﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Configuration;

namespace ShopBrigdeUI
{
    public class Globalvariable
    {
        public static HttpClient WebApiClient = new HttpClient();

        static Globalvariable()
        {
            WebApiClient.BaseAddress = new Uri(ConfigurationManager.AppSettings["ShopBirdgeWebApi"].ToString());
            WebApiClient.DefaultRequestHeaders.Clear();
            WebApiClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
    }
}